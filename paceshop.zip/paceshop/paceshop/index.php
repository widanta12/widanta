<!DOCTYPE html>
<html>

<head>
  <meta charset="utf-8">
  <title>Jersey Shop</title>
  <link rel="stylesheet" href="style.css">
</head>

<body>

  <div class="header">
    <p>Jersey Murah Aman dan Terpercaya</p>
  </div>
  <nav>
    <ul> <?php include("page/navbar.php") ?> </ul>
  </nav>

  <?php include("content.php") ?>

  <?php include("page/user/keranjang.php") ?>
  <div class="footer">
    <p>copyright by Aryantara <a href="" target="_blank">Sans</a></p>
  </div>

</body>

</html>