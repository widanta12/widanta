<div class="box-title">
    <p>Tentang / <b>Profil Pembuat</b></p>
</div>
<div id="box">

  <h1>Tentang</h1>
  <img src="img/mahasiswaa.jpeg" width="150" align="left"/>
  <table>
    <tr>
      <ul>
        <td width="25%">
          <li><b>NAMA</b></li>
        </td>
        <td>: I Gede Agus Aryantara</td>
      </ul>
    </tr>

    <tr>
      <ul>
        <td>
          <li><b>NIM</b></li>
        </td>
        <td>: 210010068</td>
      </ul>
    </tr>

    <tr>
      <ul>
        <td>
          <li><b>Hobby</b></li>
        </td>
        <td>: Bermain Catur dan Traveling ke objek wisata</td>
      </ul>
    </tr>

  

    
   

  </table>

</div>
